{
    'name':'Print SO Shipping',
    'description': 'Print SO Shipping',
    'version':'14.0.0.1',
    'author': 'Ahmed Amen',
    'data': [
    'views/template.xml',
    'views/stock_picking_sale_inherit.xml',

    ],
    'category': 'Report',
    'depends': ['sale','base','ninos_shipping_company'],
}
