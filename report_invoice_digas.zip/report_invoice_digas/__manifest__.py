{
    'name': 'Digas Invoices Report',
    'author':'Itss',
    'depends': ['base','account'],
    'data': ['views/report_invoices.xml'],
}