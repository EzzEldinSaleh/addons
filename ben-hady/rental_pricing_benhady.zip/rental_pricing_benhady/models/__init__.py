# -*- coding: utf-8 -*-

from . import rental_pricing
from . import product_template
