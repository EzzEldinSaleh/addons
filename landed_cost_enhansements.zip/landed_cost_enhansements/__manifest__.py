{
    'name': 'Landed Cost Enhancements',

    'author': 'Ezz eldin saleh',

    'depends': ['base','stock','stock_landed_costs'],
    'data': [
        'views/so_po_filed.xml'
             ],

}