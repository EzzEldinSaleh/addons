from odoo import api, fields, models
class Landed(models.Model):
    _inherit = "stock.landed.cost"
    def _compute_so_doamin(self):
        for x in self:
            if x.sale_ids and x.po_ids:
                available_pickings = x.env['stock.picking'].search(['|',('sale_id', 'in', x.sale_ids.ids),
                                                                    ('purchase_id', 'in', x.po_ids.ids)])
            elif x.sale_ids and not x.po_ids:
                available_pickings = x.env['stock.picking'].search([('sale_id', 'in', x.sale_ids.ids)])
            elif not x.sale_ids and x.po_ids:
                available_pickings = x.env['stock.picking'].search([('purchase_id', 'in', x.po_ids.ids)])
            else:
                available_pickings = x.env['stock.picking'].search([])
        return available_pickings

    sale_ids = fields.Many2many(comodel_name="sale.order", string="SOs", )
    po_ids = fields.Many2many(comodel_name="purchase.order", string="POs", )
    available_pickings = fields.Many2many(comodel_name="stock.picking", relation="hhfg", column1="gg", column2='ooj',string="Ava" ,default=_compute_so_doamin)
