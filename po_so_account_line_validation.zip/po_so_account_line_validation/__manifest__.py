{
    'name': 'SO-PO-Account validation',


    'author': 'Ezz Eldin Saleh',

    'depends': ['base','sale_management','purchase',],
    'data': [

                     ],

}