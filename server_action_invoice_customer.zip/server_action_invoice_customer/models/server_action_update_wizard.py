from odoo import api, fields, models
class wizardchange(models.TransientModel):
    _name = 'wizard.change'

    def _default_invoices(self):
        invoices = self.env.context.get('active_ids', [])
        return invoices

    invoice_ids = fields.Many2many(
        'account.move',
        default=_default_invoices
    )

    partner_id = fields.Many2one(comodel_name="res.partner", string="Partner", required=False, )
    def change_partner(self):
        for rec in self:
            for inv in rec.invoice_ids:
                if inv.state == 'draft':
                    inv.update({
                        'partner_id': rec.partner_id.id
                    })