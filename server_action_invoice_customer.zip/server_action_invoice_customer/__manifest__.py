{
    'name': 'server invoice',

    'author': 'Ezz Eldin',


    'depends': ['base','account_accountant'],
    'data': [
        'views/server_update.xml',
        'views/wizard_change.xml',
        'security/ir.model.access.csv'
             ],

}