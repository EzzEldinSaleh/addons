{
    'name': 'SO PO Order Line View',

    'author': 'EzzEldin Saleh',

    'depends': ['base','sale','purchase'],
    'data': [
        'views/sale_lines_view.xml',
        'views/purchase_lines_view.xml',
             ],
}